# Documentation changelog

The documentation is continually being improved. New releases
include new pages, fixes and updates to existing pages, and many updates
to the class reference. Below is a list of new pages
added since version 3.0.

Note

This document only contains new pages, so not all changes are reflected.
Many pages have been substantially updated but are not reflected in this document.

## New pages since version 4.6

### Editor

- Game embedding

### User Interface (UI)

- Creating applications

## New pages since version 4.5

### Input

- Controller features

### Migrating

- Upgrading from Godot 4.5 to Godot 4.6

### Platform-specific

- Resolving crashes on Android
- Wayland/X11

### Scripting

- Core functions and types

## New pages since version 4.4

### Editor

- Using the engine compilation configuration editor

### GDExtension

- GDExtension C example

### Migrating

- Upgrading from Godot 4.4 to Godot 4.5

### Scripting

- Logging

## New pages since version 4.3

### 2D

- Introduction to 2D

### 3D

- Third-person camera with spring arm

### Debug

- Output panel

### Editor

- Using the XR editor

### Migrating

- Upgrading from Godot 4.3 to Godot 4.4

### Performance

- Reducing stutter from shader (pipeline) compilations

### Physics

- Physics Interpolation
- Quick start guide
- Introduction
- Using physics interpolation
- Advanced physics interpolation
- 2D and 3D physics interpolation

### Rendering

- Overview of renderers

### Shaders

- Built-in functions

## New pages since version 4.2

### About

- System requirements

### 2D

- 2D Parallax

### Contributing

- Handling compatibility breakages

### GDExtension

- The .gdextension file
- Adding documentation

### Migrating

- Upgrading from Godot 4.2 to Godot 4.3

### Rendering

- The Compositor

### XR

- A better XR start script
- AR / Passthrough
- Where to go from here
- OpenXR Settings
- OpenXR composition layers
- OpenXR body tracking

## New pages since version 4.1

### C#

- C# diagnostics

### Development

- 2D coordinate systems and 2D transforms

### Migrating

- Upgrading from Godot 4.1 to Godot 4.2

### I/O

- Runtime file loading and saving

### Platform-specific

- Godot Android library

## New pages since version 4.0

### Development

- Internal rendering architecture
- Using sanitizers

### Migrating

- Upgrading from Godot 4.0 to Godot 4.1

### Physics

- Troubleshooting physics issues

## New pages since version 3.6

### 2D

- 2D antialiasing

### 3D

- 3D antialiasing
- Faking global illumination
- Introduction to global illumination
- Mesh level of detail (LOD)
- Occlusion culling
- Signed distance field global illumination (SDFGI)
- Using decals
- Visibility ranges (HLOD)
- Volumetric fog and fog volumes
- Variable rate shading
- Physical light and camera units

### Animation

- Creating movies

### Assets pipeline

- Retargeting 3D Skeletons

### Development

- Custom platform ports

### Migrating

- Upgrading from Godot 3 to Godot 4

### Physics

- Large world coordinates

### Scripting

- Custom performance monitors
- C# collections
- C# global classes
- C# Variant

### Shaders

- Using compute shaders

### XR

- Introducing XR tools
- The XR action map
- Deploying to Android

## New pages since version 3.5

None.

## New pages since version 3.4

### 3D

- 3D text

### Animation

- Playing videos

### Editor

- Managing editor features

## New pages since version 3.3

### GDScript

- GDScript documentation comments

## New pages since version 3.2

### 3D

- 3D rendering limitations

### About

- Troubleshooting
- List of features
- Godot release policy

### Best practices

- Version control systems

### Development

- Error macros
- Validation layers
- Configuring an IDE: Code::Blocks

### Editor

- Using the Web editor

### Export

- Exporting for dedicated servers

### Input

- Controllers, gamepads, and joysticks

### Math

- Random number generation

### Platform-specific

- Creating iOS plugins
- HTML5 shell class reference

### Physics

- Collision shapes (2D)
- Collision shapes (3D)

### Shaders

- Shaders style guide

### Scripting

- Debugger panel
- Creating script templates
- Evaluating expressions
- What is GDExtension?
- GDScript warning system (split from Static typing in GDScript)

### User Interface (UI)

- Control node gallery

## New pages since version 3.1

### Project workflow

- Gradle builds for Android

### 2D

- 2D sprite animation

### Audio

- Recording with microphone
- Sync the gameplay with audio and music

### Math

- Beziers, curves and paths
- Interpolation

### Inputs

- Input examples

### Internationalization

- Localization using gettext (PO files)

### Shading

- Your First Shader Series:
Introduction to shaders
Your first 2D shader
Your first 3D shader
Your second 3D shader
- Using VisualShaders

### Networking

- WebRTC

### Plugins

- Godot Android plugins
- Inspector plugins
- Visual Shader plugins

### Multi-threading

- Using multiple threads

### Creating content

**Procedural geometry series:**
  Procedural geometry
  Using the ArrayMesh
  Using the SurfaceTool
  Using the MeshDataTool
  Using ImmediateMesh

### Optimization

- Optimization using MultiMeshes
- Optimization using Servers

### Legal

- Complying with licenses

## New pages since version 3.0

### Step by step

- Using signals
- Exporting

### Scripting

- Static typing in GDScript

### Project workflow

Best Practices:

- Introduction
- Applying object-oriented principles in Godot
- Scene organization
- When to use scenes versus scripts
- Autoloads versus regular nodes
- When and how to avoid using nodes for everything
- Godot interfaces
- Godot notifications
- Data preferences
- Logic preferences

### 2D

- 2D lights and shadows
- 2D meshes

### 3D

- Prototyping levels with CSG
- Animating thousands of fish with MultiMeshInstance3D
- Controlling thousands of fish with Particles

### Physics

- Ragdoll system
- Using SoftBody3D

### Animation

- 2D skeletons
- Using AnimationTree

### GUI

- Using Containers

### Viewports

- Using a SubViewport as a texture
- Custom post-processing

### Shading

- Converting GLSL to Godot shaders
- Advanced post-processing

Shading Reference:

- Introduction to shaders
- Shading language
- Spatial shaders
- CanvasItem shaders
- Particle shaders

### Plugins

- Making main screen plugins
- 3D gizmo plugins

### Platform-specific

- Custom HTML page for Web export

### Multi-threading

- Thread-safe APIs

### Creating content

- Making trees

### Miscellaneous

- Fixing jitter, stutter and input lag
- Running code in the editor
- Change scenes manually

### Compiling

- Optimizing a build for size
- Compiling with PCK encryption key

### Engine development

- Binding to external libraries

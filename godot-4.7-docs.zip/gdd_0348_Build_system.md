# Build system

- Main build system: Working with SCons
- Secondary build system: Working with CMake

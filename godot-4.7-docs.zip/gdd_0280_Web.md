# Web

- The JavaScriptBridge singleton
- HTML5 shell class reference
- Custom HTML page for Web export

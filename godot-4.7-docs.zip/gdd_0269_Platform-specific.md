# Platform-specific

Godot supports both running the editor and exporting projects on several
platforms. Usage of the engine is generally similar across platforms, but there
are some platform-specific considerations, which are covered in this section.

See also

For platform-specific versions of the editor, see Using the XR editor,
Using the Android editor, and Using the Web editor. For
exporting to specific platforms, see the Export section.

- Linux
- Android
- iOS plugins
- Web

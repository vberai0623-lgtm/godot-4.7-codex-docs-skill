# Android

- Godot Android library
- Godot Android plugins
- Android in-app purchases
- Integrating with Android APIs
- Resolving crashes on Android

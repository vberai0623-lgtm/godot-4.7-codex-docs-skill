# Plugins

- Editor plugins
- Running code in the editor

# Math

- Vector math
- Advanced vector math
- Matrices and transforms
- Interpolation
- Beziers, curves and paths
- Random number generation

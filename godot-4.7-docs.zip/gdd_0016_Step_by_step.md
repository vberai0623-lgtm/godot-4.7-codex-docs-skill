# Step by step

This series builds upon the Introduction to Godot and will get you started with the editor and the
engine. You will learn more about nodes and scenes, code your first classes with
GDScript, use signals to make nodes communicate with one another, and more.

The following lessons are here to prepare you for Your first 2D game, a
step-by-step tutorial where you will code a game from scratch. By the end of it,
you will have the necessary foundations to explore more features in other
sections. We also included links to pages that cover a given topic in-depth
where appropriate.

- Nodes and Scenes
- Creating instances
- Scripting languages
- Creating your first script
- Listening to player input
- Using signals

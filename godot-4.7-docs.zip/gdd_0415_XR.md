# XR

This section of the manual covers everything related to XR (
Virtual Reality and Augmented Reality).

- XR Terminology

## Basic Tutorial

- Setting up XR
- Deploying to Android
- A better XR start script
- AR / Passthrough
- Where to go from here

## Advanced topics

- OpenXR Settings
- The XR action map
- Room scale in XR
- XR full screen effects
- OpenXR composition layers
- OpenXR hand tracking
- OpenXR body tracking
- OpenXR Render Models
- OpenXR spatial entities

## Godot XR Tools

- Introducing XR tools
- Basic XR Locomotion

# Assets pipeline

- Import process
- Importing images
- Importing audio samples
- Importing translations
- Importing 3D scenes
- Retargeting 3D Skeletons
- Exporting 3D scenes
- Blender ESCN exporter

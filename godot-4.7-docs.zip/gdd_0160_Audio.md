# Audio

- Audio buses
- Audio effects
- Audio streams
- Sync the gameplay with audio and music
- Recording with microphone
- Text to speech

# Export

See also

This section is about exporting a build of your project. If you're trying
to export properties from a script, see GDScript exported properties or
C# exported properties.

- Exporting projects
- Exporting packs, patches, and mods
- Feature tags
- Exporting for Windows
- Exporting for Linux
- Exporting for macOS
- Exporting for Android
- Exporting for iOS
- Exporting for visionOS
- Exporting for the Web
- Manually changing application icon for Windows
- Running Godot apps on macOS
- Gradle builds for Android
- One-click deploy
- Exporting for dedicated servers

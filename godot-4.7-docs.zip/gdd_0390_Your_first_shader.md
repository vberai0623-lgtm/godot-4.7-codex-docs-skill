# Your first shader

This tutorial series will walk you through writing your first shader. It is intended
for people who have very little prior experience with shaders and want to get started
with the basics. This tutorial will not cover advanced topics and it is not
comprehensive. For a comprehensive and detailed overview of shaders in Godot see the
Shading Reference Page.

The "your first shader" tutorials walk you through the process of writing a shader
step-by-step.

For a more general introduction into shaders and the OpenGL Shading Language, use
The Book of Shaders [https://thebookofshaders.com].

- Your first 2D shader
- Your first 3D shader
- Your second 3D shader

# Navigation

- 2D navigation overview
- 3D navigation overview
- Using NavigationServer
- Using NavigationMaps
- Using NavigationRegions
- Using navigation meshes
- Using NavigationPaths
- Using NavigationPathQueryObjects
- Using NavigationAgents
- Using NavigationObstacles
- Using NavigationLinks
- Using NavigationLayers
- Navigation debug tools
- Connecting navigation meshes
- Support different actor types
- Support different actor locomotion
- Support different actor area access
- Optimizing Navigation Performance

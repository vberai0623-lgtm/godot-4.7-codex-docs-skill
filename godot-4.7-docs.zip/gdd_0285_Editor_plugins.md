# Editor plugins

- Installing plugins
- Making plugins
- Making main screen plugins
- Import plugins
- 3D gizmo plugins
- Inspector plugins
- Visual Shader plugins

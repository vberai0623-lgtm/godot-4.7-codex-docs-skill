# Debug

- Overview of debugging tools
- Output panel
- Debugger panel
- The Profiler
- Using the ObjectDB profiler
- Custom performance monitors

# Linux

- Wayland/X11

# Exporting for visionOS

See also

This page describes how to export a Godot project to visionOS.
If you're looking to compile export template binaries from source instead,
see Compiling for visionOS.

Exporting instructions for visionOS are currently identical to
Compiling for iOS, except you should add a visionOS
export preset instead of iOS. See the linked page for details.

Note

Note that currently, only exporting an application for use on a flat
plane within the headset is supported. Immersive experiences are not supported.

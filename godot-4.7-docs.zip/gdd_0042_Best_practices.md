# Best practices

- Introduction
- Applying object-oriented principles in Godot
- Scene organization
- When to use scenes versus scripts
- Autoloads versus regular nodes
- When and how to avoid using nodes for everything
- Godot interfaces
- Godot notifications
- Data preferences
- Logic preferences
- Project organization
- Version control systems

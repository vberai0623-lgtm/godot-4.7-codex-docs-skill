# File and data I/O

- Background loading
- File paths in Godot projects
- Saving games
- Runtime file loading and saving
- Binary serialization API

# Scripting

This section covers programming languages and core features to code your games
in Godot.

Here, you will find information that is not already covered in more specific
sections. For instance, to learn about inputs, we recommend you to read
Inputs.

## Programming languages

The sections below each focus on a given programming language.

- GDScript
- C#/.NET
- C++ (godot-cpp)
- Other languages

## Core features

Some features are specific to the engine and are available in all supported
languages. Whether you code in GDScript, C#, or another language, the pages
below will help you make the most of Godot.

- How to read the Godot API
- Debug
- Idle and Physics Processing
- Groups
- Nodes and scene instances
- Overridable functions
- Cross-language scripting
- Creating script templates
- Evaluating expressions
- Change scenes manually
- Instancing with signals
- Pausing games and process mode
- File system
- Resources
- Singletons (Autoload)
- Using SceneTree
- Scene Unique Nodes
- Logging

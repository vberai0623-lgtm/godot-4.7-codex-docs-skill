# Shading reference

- Shading language
- Built-in functions
- Shader preprocessor
- Spatial shaders
- CanvasItem shaders
- Particle shaders
- Sky shaders
- Fog shaders
- Texture blit shaders

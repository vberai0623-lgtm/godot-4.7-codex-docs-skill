# Animating thousands of objects

- Animating thousands of fish with MultiMeshInstance3D
- Controlling thousands of fish with Particles

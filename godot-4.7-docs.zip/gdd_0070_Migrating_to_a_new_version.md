# Migrating to a new version

Godot loosely follows a semantic versioning system,
where compatibility is assumed between minor and patch releases, while major
releases can break it. As such, it is generally not recommended to move projects
between major versions during their development, especially if you've been
working on them for a significant amount of time.

Still, new features, usability improvements, or paradigm shifts in engine's
internals may incentivize you to upgrade. Below is a list of articles that should
assist you when upgrading your project between versions. Each article would try
its best to document every important difference and provide you with a migration
path.

- Upgrading from Godot 3 to Godot 4
- Upgrading from Godot 4.0 to Godot 4.1
- Upgrading from Godot 4.1 to Godot 4.2
- Upgrading from Godot 4.2 to Godot 4.3
- Upgrading from Godot 4.3 to Godot 4.4
- Upgrading from Godot 4.4 to Godot 4.5
- Upgrading from Godot 4.5 to Godot 4.6
- Upgrading from Godot 4.6 to Godot 4.7

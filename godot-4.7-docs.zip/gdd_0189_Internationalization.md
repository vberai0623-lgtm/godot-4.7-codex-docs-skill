# Internationalization

- Internationalizing games
- Localization using spreadsheets
- Localization using gettext (PO files)
- Locale codes
- Pseudolocalization

# Introduction

This series will introduce you to Godot and give you an overview of its
features.

In the following pages, you will get answers to questions such as "Is Godot for
me?" or "What can I do with Godot?". We will then introduce the engine's most
essential concepts, run you through the editor's interface, and give you tips to
make the most of your time learning it.

- Introduction to Godot
- Learn to code with GDScript
- Overview of Godot's key concepts
- First look at Godot's interface
- Learning new features
- Godot's design philosophy

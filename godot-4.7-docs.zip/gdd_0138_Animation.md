# Animation

This section of the tutorial covers using the two animation nodes in Godot
and the animation editor.

- Introduction to the animation features
- Animation Track types
- Cutout animation
- 2D skeletons
- Using AnimationTree
- Playing videos
- Creating movies

See Importing 3D scenes for information on importing animations from a 3D model.

# GDScript

- GDScript reference
- GDScript: An introduction to dynamic languages
- GDScript exported properties
- GDScript documentation comments
- GDScript style guide
- Static typing in GDScript
- GDScript warning system
- GDScript format strings
